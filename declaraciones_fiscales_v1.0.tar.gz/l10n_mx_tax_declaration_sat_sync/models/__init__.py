# -*- coding: utf-8 -*-

from . import cfdi_invoice_attachment
from . import ir_attachment
