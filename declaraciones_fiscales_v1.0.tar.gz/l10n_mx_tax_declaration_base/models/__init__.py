# -*- coding: utf-8 -*-

from . import mx_tax_obligation_type
from . import mx_tax_periodicity
from . import mx_tax_obligation
from . import mx_tax_calculation_rule
from . import account_move
from . import res_company
